﻿
namespace Point_Of_Sales_System.Presentation_Layer
{
    partial class EmployeeInformation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BackButton = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label18 = new System.Windows.Forms.Label();
            this.EmployeetextBox1 = new System.Windows.Forms.TextBox();
            this.Deletebutton = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Serachbutton = new System.Windows.Forms.Button();
            this.dateOfBirthTimePicker = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.UserIdtextBox = new System.Windows.Forms.TextBox();
            this.femaleradioButton = new System.Windows.Forms.RadioButton();
            this.maleradioButton = new System.Windows.Forms.RadioButton();
            this.label8 = new System.Windows.Forms.Label();
            this.AddresstextBox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.NameTextBox = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.PasswordtextBox = new System.Windows.Forms.TextBox();
            this.UserNametextBox = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.EmailtextBox = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.EmployeeTextBox = new System.Windows.Forms.TextBox();
            this.Editbutton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.EmployeeListDataGridView = new System.Windows.Forms.DataGridView();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.EmployeeListDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // BackButton
            // 
            this.BackButton.BackColor = System.Drawing.Color.Linen;
            this.BackButton.Image = global::Point_Of_Sales_System.Properties.Resources.Arrows_Left_icon;
            this.BackButton.Location = new System.Drawing.Point(0, -2);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(43, 32);
            this.BackButton.TabIndex = 13;
            this.BackButton.UseVisualStyleBackColor = false;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Controls.Add(this.EmployeetextBox1);
            this.groupBox3.Controls.Add(this.Deletebutton);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F);
            this.groupBox3.Location = new System.Drawing.Point(411, 228);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox3.Size = new System.Drawing.Size(292, 119);
            this.groupBox3.TabIndex = 71;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Delete Employee";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F);
            this.label18.Location = new System.Drawing.Point(17, 36);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(80, 19);
            this.label18.TabIndex = 64;
            this.label18.Text = "EmployeeId";
            // 
            // EmployeetextBox1
            // 
            this.EmployeetextBox1.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F);
            this.EmployeetextBox1.Location = new System.Drawing.Point(113, 36);
            this.EmployeetextBox1.Margin = new System.Windows.Forms.Padding(2);
            this.EmployeetextBox1.Name = "EmployeetextBox1";
            this.EmployeetextBox1.Size = new System.Drawing.Size(139, 24);
            this.EmployeetextBox1.TabIndex = 63;
            // 
            // Deletebutton
            // 
            this.Deletebutton.BackColor = System.Drawing.Color.Gold;
            this.Deletebutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Deletebutton.Location = new System.Drawing.Point(11, 63);
            this.Deletebutton.Margin = new System.Windows.Forms.Padding(2);
            this.Deletebutton.Name = "Deletebutton";
            this.Deletebutton.Size = new System.Drawing.Size(88, 29);
            this.Deletebutton.TabIndex = 41;
            this.Deletebutton.Text = "Delete";
            this.Deletebutton.UseVisualStyleBackColor = false;
            this.Deletebutton.Click += new System.EventHandler(this.Deletebutton_Click_1);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Serachbutton);
            this.groupBox2.Controls.Add(this.dateOfBirthTimePicker);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.UserIdtextBox);
            this.groupBox2.Controls.Add(this.femaleradioButton);
            this.groupBox2.Controls.Add(this.maleradioButton);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.AddresstextBox);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.NameTextBox);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.PasswordtextBox);
            this.groupBox2.Controls.Add(this.UserNametextBox);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.EmailtextBox);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.EmployeeTextBox);
            this.groupBox2.Controls.Add(this.Editbutton);
            this.groupBox2.Location = new System.Drawing.Point(11, 44);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox2.Size = new System.Drawing.Size(357, 312);
            this.groupBox2.TabIndex = 70;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Update Employee";
            // 
            // Serachbutton
            // 
            this.Serachbutton.BackColor = System.Drawing.Color.Gold;
            this.Serachbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Serachbutton.Location = new System.Drawing.Point(202, 28);
            this.Serachbutton.Margin = new System.Windows.Forms.Padding(2);
            this.Serachbutton.Name = "Serachbutton";
            this.Serachbutton.Size = new System.Drawing.Size(88, 26);
            this.Serachbutton.TabIndex = 87;
            this.Serachbutton.Text = "Search";
            this.Serachbutton.UseVisualStyleBackColor = false;
            this.Serachbutton.Click += new System.EventHandler(this.Serachbutton_Click_1);
            // 
            // dateOfBirthTimePicker
            // 
            this.dateOfBirthTimePicker.Location = new System.Drawing.Point(101, 161);
            this.dateOfBirthTimePicker.Margin = new System.Windows.Forms.Padding(2);
            this.dateOfBirthTimePicker.Name = "dateOfBirthTimePicker";
            this.dateOfBirthTimePicker.Size = new System.Drawing.Size(189, 20);
            this.dateOfBirthTimePicker.TabIndex = 86;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F);
            this.label3.Location = new System.Drawing.Point(-4, 161);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 19);
            this.label3.TabIndex = 85;
            this.label3.Text = "DateOfBirth";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F);
            this.label7.Location = new System.Drawing.Point(-1, 247);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 19);
            this.label7.TabIndex = 84;
            this.label7.Text = "UserId";
            // 
            // UserIdtextBox
            // 
            this.UserIdtextBox.Location = new System.Drawing.Point(101, 248);
            this.UserIdtextBox.Margin = new System.Windows.Forms.Padding(2);
            this.UserIdtextBox.Name = "UserIdtextBox";
            this.UserIdtextBox.Size = new System.Drawing.Size(185, 20);
            this.UserIdtextBox.TabIndex = 83;
            // 
            // femaleradioButton
            // 
            this.femaleradioButton.AutoSize = true;
            this.femaleradioButton.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F);
            this.femaleradioButton.Location = new System.Drawing.Point(162, 189);
            this.femaleradioButton.Margin = new System.Windows.Forms.Padding(2);
            this.femaleradioButton.Name = "femaleradioButton";
            this.femaleradioButton.Size = new System.Drawing.Size(68, 23);
            this.femaleradioButton.TabIndex = 82;
            this.femaleradioButton.TabStop = true;
            this.femaleradioButton.Text = "female";
            this.femaleradioButton.UseVisualStyleBackColor = true;
            // 
            // maleradioButton
            // 
            this.maleradioButton.AutoSize = true;
            this.maleradioButton.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F);
            this.maleradioButton.Location = new System.Drawing.Point(101, 189);
            this.maleradioButton.Margin = new System.Windows.Forms.Padding(2);
            this.maleradioButton.Name = "maleradioButton";
            this.maleradioButton.Size = new System.Drawing.Size(57, 23);
            this.maleradioButton.TabIndex = 81;
            this.maleradioButton.TabStop = true;
            this.maleradioButton.Text = "Male";
            this.maleradioButton.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F);
            this.label8.Location = new System.Drawing.Point(-1, 218);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 19);
            this.label8.TabIndex = 80;
            this.label8.Text = "Address";
            // 
            // AddresstextBox
            // 
            this.AddresstextBox.Location = new System.Drawing.Point(101, 216);
            this.AddresstextBox.Margin = new System.Windows.Forms.Padding(2);
            this.AddresstextBox.Name = "AddresstextBox";
            this.AddresstextBox.Size = new System.Drawing.Size(185, 20);
            this.AddresstextBox.TabIndex = 79;
            // 
            // label9
            // 
            this.label9.AccessibleName = "";
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F);
            this.label9.Location = new System.Drawing.Point(-1, 191);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(54, 19);
            this.label9.TabIndex = 78;
            this.label9.Text = "Gender";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F);
            this.label10.Location = new System.Drawing.Point(0, 56);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(46, 19);
            this.label10.TabIndex = 74;
            this.label10.Text = "Name";
            // 
            // NameTextBox
            // 
            this.NameTextBox.Location = new System.Drawing.Point(101, 57);
            this.NameTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.NameTextBox.Name = "NameTextBox";
            this.NameTextBox.Size = new System.Drawing.Size(189, 20);
            this.NameTextBox.TabIndex = 70;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F);
            this.label11.Location = new System.Drawing.Point(-1, 134);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(67, 19);
            this.label11.TabIndex = 77;
            this.label11.Text = "password";
            // 
            // PasswordtextBox
            // 
            this.PasswordtextBox.Location = new System.Drawing.Point(101, 133);
            this.PasswordtextBox.Margin = new System.Windows.Forms.Padding(2);
            this.PasswordtextBox.Name = "PasswordtextBox";
            this.PasswordtextBox.PasswordChar = '*';
            this.PasswordtextBox.Size = new System.Drawing.Size(189, 20);
            this.PasswordtextBox.TabIndex = 73;
            // 
            // UserNametextBox
            // 
            this.UserNametextBox.Location = new System.Drawing.Point(101, 81);
            this.UserNametextBox.Margin = new System.Windows.Forms.Padding(2);
            this.UserNametextBox.Name = "UserNametextBox";
            this.UserNametextBox.Size = new System.Drawing.Size(189, 20);
            this.UserNametextBox.TabIndex = 71;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F);
            this.label12.Location = new System.Drawing.Point(-1, 110);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(41, 19);
            this.label12.TabIndex = 76;
            this.label12.Text = "Email";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F);
            this.label17.Location = new System.Drawing.Point(-1, 80);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(69, 19);
            this.label17.TabIndex = 75;
            this.label17.Text = "username";
            // 
            // EmailtextBox
            // 
            this.EmailtextBox.Location = new System.Drawing.Point(101, 109);
            this.EmailtextBox.Margin = new System.Windows.Forms.Padding(2);
            this.EmailtextBox.Name = "EmailtextBox";
            this.EmailtextBox.Size = new System.Drawing.Size(189, 20);
            this.EmailtextBox.TabIndex = 72;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(-1, 31);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(80, 19);
            this.label19.TabIndex = 67;
            this.label19.Text = "EmployeeId";
            // 
            // EmployeeTextBox
            // 
            this.EmployeeTextBox.Location = new System.Drawing.Point(101, 31);
            this.EmployeeTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.EmployeeTextBox.Name = "EmployeeTextBox";
            this.EmployeeTextBox.Size = new System.Drawing.Size(89, 20);
            this.EmployeeTextBox.TabIndex = 66;
            // 
            // Editbutton
            // 
            this.Editbutton.BackColor = System.Drawing.Color.Gold;
            this.Editbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Editbutton.Location = new System.Drawing.Point(0, 276);
            this.Editbutton.Margin = new System.Windows.Forms.Padding(2);
            this.Editbutton.Name = "Editbutton";
            this.Editbutton.Size = new System.Drawing.Size(88, 32);
            this.Editbutton.TabIndex = 43;
            this.Editbutton.Text = "Edit";
            this.Editbutton.UseVisualStyleBackColor = false;
            this.Editbutton.Click += new System.EventHandler(this.Editbutton_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(419, 35);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 18);
            this.label1.TabIndex = 69;
            this.label1.Text = "Employee List";
            // 
            // EmployeeListDataGridView
            // 
            this.EmployeeListDataGridView.AllowUserToAddRows = false;
            this.EmployeeListDataGridView.AllowUserToDeleteRows = false;
            this.EmployeeListDataGridView.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.EmployeeListDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.EmployeeListDataGridView.Location = new System.Drawing.Point(411, 60);
            this.EmployeeListDataGridView.Margin = new System.Windows.Forms.Padding(2);
            this.EmployeeListDataGridView.Name = "EmployeeListDataGridView";
            this.EmployeeListDataGridView.ReadOnly = true;
            this.EmployeeListDataGridView.RowHeadersWidth = 51;
            this.EmployeeListDataGridView.RowTemplate.Height = 24;
            this.EmployeeListDataGridView.Size = new System.Drawing.Size(292, 164);
            this.EmployeeListDataGridView.TabIndex = 68;
            // 
            // EmployeeInformation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Bisque;
            this.ClientSize = new System.Drawing.Size(711, 353);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.EmployeeListDataGridView);
            this.Controls.Add(this.BackButton);
            this.Name = "EmployeeInformation";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Edit Employee";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.EmployeeInformation_FormClosing_1);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.EmployeeListDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox EmployeetextBox1;
        private System.Windows.Forms.Button Deletebutton;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DateTimePicker dateOfBirthTimePicker;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox UserIdtextBox;
        private System.Windows.Forms.RadioButton femaleradioButton;
        private System.Windows.Forms.RadioButton maleradioButton;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox AddresstextBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox NameTextBox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox PasswordtextBox;
        private System.Windows.Forms.TextBox UserNametextBox;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox EmailtextBox;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox EmployeeTextBox;
        private System.Windows.Forms.Button Editbutton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView EmployeeListDataGridView;
        private System.Windows.Forms.Button Serachbutton;
    }
}